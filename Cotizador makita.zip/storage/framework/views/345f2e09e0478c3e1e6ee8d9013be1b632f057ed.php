<ul class="sidebar-menu">
    <li class="header"></li>

    <li class="treeview">
        <a href="<?php echo e(url('clientes')); ?>">
        <i class="fa fa-user"></i>
        <span>Clientes</span>
      </a>
    </li>

    <li class="treeview">
      <a href="<?php echo e(url('productos')); ?>">
        <i class="fa fa-cogs"></i>
        <span>Productos</span>
      </a>
    </li>
    <li class="treeview">
      <a href="<?php echo e(url('cotizaciones')); ?>">
        <i class="fa fa-money"></i>
        <span>Cotizaciones</span>
      </a>
    </li>

    <li class="treeview">
      <a href="<?php echo e(url('vendedores')); ?>">
        <i class="fa fa-paypal"></i> <span>Vendedores</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(url('perfil')); ?>">
        <i class="fa fa-info-circle"></i> <span>Perfil</span>
      </a>
    </li>
    <li>
      <a href="<?php echo e(url('papeletas')); ?>">
        <i class="fa fa-info-circle"></i> <span>Papeletas</span>
      </a>
    </li>
    <!-- <li>
      <a href="<?php echo e(url('reportes')); ?>">
        <i class="fa fa-area-chart"></i> <span>Reportes</span>
        <small class="label pull-right bg-yellow">IT</small>
      </a>
    </li> -->
</ul>