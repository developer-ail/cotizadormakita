<?php $__env->startSection('contenido'); ?>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <h3>Modificar datos de cliente</h3>
            <?php if(count($errors)>0): ?>
            <div class="alert alert-danger">
              <ul>
                <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
              </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php echo Form::model($cliente,['method'=>'PUT','route'=>['clientes.update',$cliente->id]]); ?>

    <?php echo e(Form::token()); ?>


      <div class="row">
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
              <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" required value="<?php echo e($cliente->nombre); ?>" class="form-control" placeholder="Nombre..">
              </div>
          </div>
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
              <div class="form-group">
                <label for="direccion">Dirección</label>
                <input type="text" name="direccion" value="<?php echo e($cliente->direccion); ?>" class="form-control" placeholder="Dirección fiscal">
              </div>
          </div>
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
              <div class="form-group">
                <label for="telefono">Teléfono</label>
                <input type="tel" name="telefono" value="<?php echo e($cliente->telefono); ?>" class="form-control" placeholder="No de telefono personal">
              </div>
          </div>
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
              <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" name="email" value="<?php echo e($cliente->email); ?>" class="form-control" placeholder="Correo electronico">
              </div>
          </div>
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="form-group">
              <label for="atencion">Atención</label>
              <input type="text" name="atencion" value="<?php echo e($cliente->atencion); ?>" class="form-control" placeholder="Persona de contacto con el cliente">
            </div>
        </div>
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
              <div class="form-group">
                <label for="rfc">RFC</label>
                <input type="text" name="rfc" value="<?php echo e($cliente->rfc); ?>" class="form-control" placeholder="RFC..">
              </div>
          </div>
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
              <div class="form-group">
                <label for="razon_social">Razón social</label>
                <input type="text" name="razon_social" value="<?php echo e($cliente->razon_social); ?>" class="form-control" placeholder="Razón social..">
              </div>
          </div>

          <?php if(Auth::user()->tipo_usuario == 'admin'): ?>
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
              <div class="form-group">
                  <label>Vendedor asignado</label>
                  <select class="form-control" name="vendedor">
                      <option value="<?php echo e($vendedor->id); ?>"><?php echo e($vendedor->nombre); ?></option>
                      <?php foreach($vendedores as $ven): ?>
                          <<option value="<?php echo e($ven->id); ?>"><?php echo e($ven->nombre); ?></option>
                      <?php endforeach; ?>
                  </select>
              </div>
          </div>
          <?php endif; ?>
          <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
            <div class="form-group">
              <button type="submit" class="btn btn-primary">Guardar</button>
              <button type="reset" class="btn btn-danger">Cancelar</button>
            </div>
          </div>
      </div>

      <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>