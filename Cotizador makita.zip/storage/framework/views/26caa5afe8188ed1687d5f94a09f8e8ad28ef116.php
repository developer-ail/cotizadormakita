<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
      <h3>Relación de cotizaciones</h3>
      <?php echo $__env->make('cotizaciones.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" style="">

  </div>
</div>

<!--  -->
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="table-responsive">
        <table class="table table-striped table-bordered table-condensed table-hover">
          <thead>
            <th>Id</th>
            <th>Cliente</th>
            <th>Id Cliente</th>
            <th>Email</th>
            <th>Vendedor</th>
            <th>Id Vendedor</th>
            <th>Fecha</th>
            <th>Total</th>
            <th>Folio</th>
            <th>Operaciones</th>
        </thead>

        <?php foreach($cotizaciones as $cot): ?>
        <tr>
            <td><?php echo e($cot->id); ?></td>
            <td><?php echo e($cot->cliente); ?></td>
            <td><?php echo e($cot->id_cliente); ?></td>
            <td><?php echo e($cot->email); ?></td>
            <td><?php echo e($cot->vendedor); ?></td>
            <td><?php echo e($cot->id_vendedor); ?></td>
            <th><?php echo e($cot->fecha); ?></th>
            <th>$ <?php echo e(number_format($cot->total, 2, '.', ',')); ?></th>
            <th><?php echo e($cot->folio); ?></th>
            <td>
                <a href="<?php echo e(URL::action('CotizacionesController@show',$cot->id)); ?>"><button class="btn btn-primary"><i class="fa fa-eye" aria-hidden="true"></i></button></a>
                <a href="<?php echo e(URL::action('CotizacionesController@imprimir',['id_vendedor'=>$cot->id_vendedor,'id_cliente'=>$cot->id_cliente,'id_cotizacion'=>$cot->id,'fecha'=>$cot->fecha])); ?>"><button class="btn btn-info"><i class="fa fa-print" aria-hidden="true"></i></button></a>
                <a href="<?php echo e(URL::action('CotizacionesController@enviar',['id_vendedor'=>$cot->id_vendedor,'id_cliente'=>$cot->id_cliente,'id_cotizacion'=>$cot->id,'fecha'=>$cot->fecha])); ?>"><button class="btn btn-success"><i class="fa fa-envelope" aria-hidden="true"></i></button></a>
            </td>
        </tr>
      <?php endforeach; ?>
  </table>
</div>
<?php echo e($cotizaciones->render()); ?>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>