<?php $__env->startSection('contenido'); ?>

<div class="container-fluid">
	<div class="row text-center">
		<h1>Artículos Innovadores Leo</h1>
		<h2>Perfil de usuario</h2>
	</div>
	<div class="row">
		<div class="col-sm-12 col-md-4 col-lg-4">
			<img src="<?php echo e(asset('img/users/'.$usuario->image)); ?>" class="img img-responsive img-circle text-center" style="width: 250px; height: 250px; margin-bottom: 25px;">
		</div>
		<div class="col-sm-12 col-md-8 col-lg-8">
			<table class="table table-condensed">
				<thead>
					<tr>
						<th>Campos</th>
						<th>Datos</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<th>Id</th>
						<th><?php echo e($usuario->id); ?></th>
					</tr>
					<tr>
						<th>Nombre</th>
						<th><?php echo e($usuario->name); ?></th>
					</tr>
					<tr>
						<th>Email</th>
						<th><?php echo e($usuario->email); ?></th>
					</tr>
					<tr>
						<th>Tipo de usuario</th>
						<th><?php echo e($usuario->tipo_usuario); ?></th>
					</tr>
				</tbody>
			</table>
			<a href="<?php echo e(URL::action('PerfilController@edit',$usuario->id)); ?>" class="btn btn-info">Actualizar</a>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>