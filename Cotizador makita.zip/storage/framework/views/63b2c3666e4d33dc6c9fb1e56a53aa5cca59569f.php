<h1>Listado de productos</h1>

<br><br>

<ul>
    <?php foreach($productos as $pro): ?>
        <li>
            <img src="<?php echo e(asset('imagenes').'/'.$pro->modelo.'.jpg'); ?>" class="img-responsive" style="width:100px;"> - <?php echo e($pro->modelo); ?>

        </li>
    <?php endforeach; ?>
</ul>