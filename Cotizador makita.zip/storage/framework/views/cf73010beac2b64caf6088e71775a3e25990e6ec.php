<?php $__env->startSection('contenido'); ?>

   <h1 class="text-center">Artículos Innovadores Leo</h1>
   <h2 class="text-center">Cotización Makita</h2>

   <div class="container-fluid">
        <div class="col-xs-12 col-md-6">
            <h3>Datos del cliente</h3>
            <?php echo Form::open(array('url'=>'enviar_cotizacion','method'=>'POST','autocomplete'=>'off','name'=>'formulario1')); ?>

            <?php echo e(Form::token()); ?>

            <table class="table table-bordered table-striped table-hover">
                <tbody>
                    <tr>
                        <th scope="row">Fecha</th>
                        <th><input type="text" name="fecha" id="" value="<?php echo e(date("d/m/Y")); ?> <?php echo e(date("g:i a")); ?>"></th>
                    </tr>
                    <tr>
                        <th>Cliente</th>
                        <th>
                            <div class="form-group">
                                <select class="form-control" name="cliente" id="cliente" onchange="validar_cliente()" required="true">
                                    <option value="0">Seleccionar cliente</option>
                                    <?php foreach($clientes as $cli): ?>
                                        <option value="<?php echo e($cli->id); ?>"><?php echo e($cli->nombre); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </th>
                    </tr>
                    <tr>
                        <th>Atención</th>
                        <th>
                            <input type="text" name="atn" placeholder="Nombre de contacto con la empresa" class="form-control" id="atencion">
                        </th>
                    </tr>
                    <tr>
                        <th>Télefono</th>
                        <th>
                            <input type="tel" name="tel" placeholder="Telefono de contacto" class="form-control" id="telefono">
                        </th>
                    </tr>
                    <tr>
                        <th>Correo</th>
                        <th>
                            <input type="tel" name="email" placeholder="Correo electronico de contacto" class="form-control" id="email">
                        </th>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-xs-12 col-md-6">
            <h3>Datos del vendedor</h3>
            <table class="table table-striped table-inverse table-responsive">
                <tbody>
                    <tr>
                        <td scope="row">Empresa</td>
                        <td>Artículos Innovadores Leo S.A. de C.V. </td>
                    </tr>
                    <tr>
                        <td>Vendedor</td>
                        <td>
                            <div class="form-group">
                                <select class="form-control" name="vendedor" id="vendedor" onchange="validad_vendedor()" required="true">
                                    <option value="0">Seleccionar vendedor</option>
                                    <?php foreach($vendedores as $ven): ?>
                                        <option value="<?php echo e($ven->id); ?>"><?php echo e($ven->nombre); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Dirección</td>
                        <td>Cafetal No. 368 Col. Granjas México Del. Iztacalco, C.P. 08400</td>
                    </tr>
                    <tr>
                        <td>Télefono</td>
                        <td>(55)2235-5565</td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>
                            <input type="text" name="email_vendedor" id="email_vendedor" placeholder="email del vendedor" class="form-control">
                        </td>
                    </tr>
                    <tr>
                        <th>Folio</th>
                        <th>002</th>
                    </tr>
                </tbody>
            </table>
        </div>
   </div>

   <div class="contrainer-fluid">
        <?php foreach($producto as $pro): ?>
        <div class="row">
            <div class="col-xs-12 col-md-4">
                <!-- <img src="<?php echo e(asset('imagenes').'/'.$pro->modelo.'.jpg'); ?>" class="img-responsive"> -->
                <?php if( file_exists(public_path().'/imagenes/'.$pro->modelo.'.jpg')): ?>
                    <img src="<?php echo e(asset('imagenes').'/'.$pro->modelo.'.jpg'); ?>" class="img-responsive">
                <?php elseif(file_exists(public_path().'/imagenes/'.$pro->modelo.'.png') ): ?>
                    <img src="<?php echo e(asset('imagenes').'/'.$pro->modelo.'.png'); ?>" class="img-responsive">
                <?php else: ?>
                    <img src="<?php echo e(asset('imagenes/No_disponible.jpg')); ?>" class="img-responsive">
                <?php endif; ?>
            </div>
            <div class="col-xs-12 col-md-8">
            <table class="table">
                <thead>
                    <tr>
                    <th scope="col">Campos</th>
                    <th scope="col">Datos</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                    <th scope="row">Modelo</th>
                    <th><?php echo e($pro->modelo); ?></th>
                    </tr>
                    <tr>
                    <th scope="row">Descripción</th>
                    <th><?php echo e($pro->descripcion); ?></th>
                    </tr>
                    <tr>
                    <th scope="row">Unidad</th>
                    <th><?php echo e($pro->unidad); ?></th>
                    </tr>
                    <tr>
                    <th scope="row">Moneda</th>
                    <th><?php echo e($pro->moneda); ?></th>
                    </tr>
                    <tr>
                    <th scope="row">Precio unitario</th>
                    <th>$ <?php echo e(number_format($pro->precio_unitario, 2, '.', ',')); ?></th>
                    </tr>
                    <tr>
                    <th scope="row">Precio c/IVA</th>
                    <th>$ <?php echo e(number_format($pro->precio_venta, 2, '.', ',')); ?></th>
                    </tr>
                    <tr>
                    <th>Cantidad</th>
                    <th><?php echo e($pro->cantidad); ?></th>
                    
                    <th>
                        <form class="" action="modificarcant" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="number" name="cantidad" placeholder="Indicar cantidad a modificar" class="form-control">
                            <input type="hidden" name="id_prod" value="<?php echo e($pro->id); ?>">
                        </form>
                    </th>
                    </tr>
                    <tr>
                    <th>Sub total</th>
                    <th>$ <?php echo e(number_format($pro->precio_venta * $pro->cantidad, 2, '.', ',')); ?></th>
                    <th>
                        <form class="" action="eliminaritem" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id_elemento" value="<?php echo e($pro->id_elemento); ?>">
                            <input type="submit" class="form-control btn-danger" value="Eliminar">
                            <?php /* <input type="hidden" name="id_prod" value="<?php echo e($pro->id); ?>"> */ ?>
                        </form>
                    </th>
                    </tr>
                </tbody>
                </table>
            </div>
        </div>
        <?php endforeach; ?>


   </div>
   <div class="container-fluid">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Resumen de la cotización
            </div>
            <div class="panel-body">
                <table class="table table-striped table-inverse table-responsive">
                    <tr>
                        <td>Total:</td>
                        <td><strong style="color:red;font-size:2em;">$ <?php echo e(number_format($total, 2, '.', ',')); ?></strong></td>
                        <input type="text" name="total_cotizacion" value="<?php echo e($total); ?>">
                        <td>
                            <?php /* <a href="enviar_cotizacion" class="btn btn-success">Enviar cotización</a> */ ?>
                            <input type="button" value="Enviar cotizacion" class="btn btn-primary" onclick="enviar()">
                            <a href="borrarcotizacion" class="btn btn-danger">Borrar cotizacion</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
   </div>
</form>

<?php $__env->stopSection(); ?>

<script>

    function validar_cliente(){
        var id_cliente = $('#cliente option:selected').val();
        
        var parametros ={
            'id_cliente' : id_cliente
        };
        //alert(parametros.id_cliente);

        $.ajax({
            data: parametros,
            url: "<?php echo e(url('validar')); ?>",
            type : 'get',
            beforeSend: function () {
                //alert("Obteniendo datos del cliente");
            },
            success: function(respuesta){
                
                $("#telefono").val(respuesta['telefono']);
                $("#email").val(respuesta['email']);
                $("#atencion").val(respuesta['atencion']);
            },
            error: function(xhr, status){
                alert('No se pudo consultar los datos revise su conexión');
            }
        });
    }

    function validad_vendedor(){
        var id_vendedor = $('#vendedor option:selected').val();
        
        var parametros ={
            'id_vendedor' : id_vendedor
        };
        
        $.ajax({
            data: parametros,
            url: "<?php echo e(url('validar_vendedor')); ?>",
            type : 'get',
            beforeSend: function () {
                //alert("Obteniendo datos del cliente");
            },
            success: function(respuesta){
                
                $("#email_vendedor").val(respuesta.email);
            },
            error: function(xhr, status){
                alert('No se pudo consultar los datos revise su conexión');
            }
        });
    }

    function enviar(){
        var id_cliente = $('#cliente option:selected').val();
        var id_vendedor = $('#vendedor option:selected').val();
        if(id_cliente==0 || id_vendedor ==0){
            alert("No se ha seleccionado cliente o vendedor, Favor de revisar sus datos");
        }else{
            document.formulario1.submit();    
        }
    }

</script>
<?php echo $__env->make('layout/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>