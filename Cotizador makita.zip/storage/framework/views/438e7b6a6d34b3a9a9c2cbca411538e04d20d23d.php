<?php $__env->startSection('contenido'); ?>
<div class="row">
    <?php if(session('message')): ?>
        <div class="alert alert-warning" role="alert">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
</div>

<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>PAPELETAS <a href="papeletas/create"><button class="btn btn-success">Nuevo</button></a></h3>
        <?php echo $__env->make('papeletas.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>

<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover table-fixed">
                <thead>
                    <th>Id</th>
                    <th>Empresa</th>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Producto</th>
                    <th>Marca</th>
                    <th>C/Nuevo</th>
                    <th>Medio</th>
                </thead>
                <tbody>
                <?php foreach($papeletas as $p): ?>
                <tr>
                    <td><?php echo e($p->id); ?></td>
                    <td><?php echo e($p->empresa); ?></td>
                    <td><?php echo e($p->nombre); ?></td>
                    <td><?php echo e($p->email); ?></td>
                    <th><?php echo e($p->telefono); ?></th>
                    <th><?php echo e($p->producto); ?></th>
                    <th><?php echo e($p->marca); ?></th>
                    <th><?php echo e($p->cliente_nuevo); ?></th>
                    <th><?php echo e($p->contacto); ?></th>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo e($papeletas->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>