<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Papeletas extends Model
{
    protected $table = 'papeletas';
}
