<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class detallePedido extends Model
{
    protected $table = 'detalle_pedido';
}
