<ul class="sidebar-menu">
    <li class="header"></li>
    <li class="treeview">
        <a href="{{url('clientes')}}">
        <i class="fa fa-laptop"></i>
        <span>Clientes</span>
      </a>
    </li>
    <li class="treeview">
      <a href="{{url('productos')}}">
        <i class="fa fa-th"></i>
        <span>Productos</span>
      </a>
    </li>
    <li class="treeview">
      <a href="{{url('cotizaciones')}}">
        <i class="fa fa-shopping-cart"></i>
        <span>Cotizaciones</span>
      </a>
    </li>
    <li>
      <a href="{{url('perfil')}}">
        <i class="fa fa-info-circle"></i> <span>Perfil</span>
      </a>
    </li>
    <li>
      <a href="{{url('papeletas')}}">
        <i class="fa fa-info-circle"></i> <span>Papeletas</span>
      </a>
    </li>
</ul>