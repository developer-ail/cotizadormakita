<ul class="sidebar-menu">
        <li class="header"></li>
        <li class="treeview">
          <a href="{{url('productos')}}">
            <i class="fa fa-th"></i>
            <span>Productos</span>
          </a>
        </li>
        <li class="treeview">
          <a href="{{url('cotizaciones')}}">
            <i class="fa fa-shopping-cart"></i>
            <span>Cotizaciones</span>
          </a>
        </li>
        
    </ul>